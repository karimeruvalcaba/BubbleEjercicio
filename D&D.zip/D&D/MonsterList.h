#include "Monster.h"


class MonsterList {
private:
    Monster* head;

public:
    // Constructor
    MonsterList() : head(nullptr) {}

    // Destructor
    ~MonsterList() {
        //clear();
    }

  void addMonster(const string& name, double cr, const string& type, const string& size, int ac, int hp, const string& align);

  void displayMonsters();
};