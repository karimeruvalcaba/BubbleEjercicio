#include "MonsterList.h"
#include <iostream>
using namespace std;


// Add a monster to the end of the list
    void MonsterList::addMonster(const string& name, double cr, const string& type, const string& size, int ac, int hp, const string& align) {
        Monster* newMonster = new Monster(name, cr, type, size, ac, hp, align);
        if (!head) {
            head = newMonster;
        } else {
            Monster* current = head;
            while (current->getNext()) {
                current = current->getNext();
            }
            current->setNext(newMonster);
        }
    }

    // Display all monsters in the list
void MonsterList::displayMonsters() {
        Monster* current = head;
        while (current) {
            cout << "Name: " << current->getName() << endl;
            cout << "CR: " << current->getCr() << endl;
            cout << "Type: " << current->getType() << endl;
            cout << "Size: " << current->getSize() << endl;
            cout << "AC: " << current->getAc() << endl;
            cout << "HP: " << current->getHp() << endl;
            cout << "Alignment: " << current->getAlign() << endl;
            cout << "------------------------" << endl;
            current = current->getNext();
        }

    }